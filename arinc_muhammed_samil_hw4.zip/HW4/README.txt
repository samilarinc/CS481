# Makefile

This makefile just contains a line to run my code with python3. It uses 
--ref sequence.fasta
--qry queries.fasta
--k 3
--s 4
as input arguments. If you want to use your own files or arguments you should change makefile.

## Usage

The argument list of the CLI is same as the example given in HW assignment.

python3 hw4.py ––ref REFERENCE_FILE ––qry QUERY_FILE ––k KMER_LENGTH ––s SCORE_THRESHOLD

## Classes
It imports numpy module

